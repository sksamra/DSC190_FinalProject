#!/usr/bin/env python

import asyncio
import json
import logging
import websockets
import webbrowser
import sys
import random

import numpy as np
import os
import pandas as pd
from scipy import stats
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import FunctionTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import OrdinalEncoder
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.tree import plot_tree
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.neighbors import NearestCentroid
from sklearn.neural_network import MLPClassifier
import time
import joblib


# CITE: https://websockets.readthedocs.io/en/stable/intro.html
# WS server example that synchronizes state across clients

async def notify_message(messageId):
    if USERS:  # asyncio.wait doesn't accept an empty list
        print(messageId)
        message = json.dumps({"type": "message", "id": messageId})
        await asyncio.wait([user.send(message) for user in USERS])

async def f1score_message(score):
    if USERS:  # asyncio.wait doesn't accept an empty list
        message = json.dumps({"type": "f1score", "value": score})
        await asyncio.wait([user.send(message) for user in USERS])

async def predict_message(score):
    if USERS:  # asyncio.wait doesn't accept an empty list
        message = json.dumps({"type": "predict", "value": score})
        await asyncio.wait([user.send(message) for user in USERS])


models = {}
df = pd.DataFrame()
label = ""
# z-scale for quantative data
def z_scale(x):
    return (x-x.mean())/x.std()
def nop(x):
    return x

async def load_dataset():
	global df
	global models
	global label
	global x_test
	global y_test

	await notify_message("Loading Model....")

	df = pd.read_csv("cleaned_data.csv")


	# Load pipelines
	for classfier in ["decisiontree", "randomforest", "bagging", "svc", "nbayes", "ncentroid"]:
			await notify_message("Loading Model: " + classfier + " ...")
			pipeline = joblib.load('models/pipeline_'+classfier+'.pkl')
			pipeline.named_steps[classfier].model = joblib.load('models/model_'+classfier+'.pkl')
			models[classfier] = pipeline
		

	await notify_message("Split Train Validate Test...")

	label = 'Older_Driver'
	# split it into training, validation, and test splits, with a 60/20/20% 
	x_train_validate, x_test, y_train_validate, y_test = train_test_split(df.drop(label, axis=1), df[label], test_size=0.2, random_state=42)
	# now split train_validate into train (75%) and validate (25%)
	x_train, x_validate, y_train, y_validate = train_test_split(x_train_validate, y_train_validate, test_size=0.25, random_state=42)



	await notify_message("")


async def do_prediction(data):
	result = 0

	test2 = x_test.iloc[0:100].copy()
	classifier = ""
	for d in data:
		if d["name"] == "classifier":
			classifier = d["value"]
			print("Classifier = " + classifier)
			continue

		if d["name"] == "LA name":
			test2.loc[test2.index[0], d["name"]] = d["value"]
		else:
			test2.loc[test2.index[0], d["name"]] = int(d["value"])
	
	try:
		y_pred = models[classifier].predict(test2)
		#print(y_pred[0], y_test.iloc[0])
		if y_pred[0]:
			await predict_message("Old Driver")
		else:
			await predict_message("Young Driver")
		
	finally:
		pass

async def do_test_prediction(data):
	await notify_message("Calculating Test Predictions...")

	classifier = ""
	for d in data:
		if d["name"] == "classifier":
			classifier = d["value"]
			print("Classifier = " + classifier)
			continue

	try:
		# TODO : change model...
		y_pred = models[classifier].predict(x_test)
		cf_matrix = confusion_matrix(y_true=y_test, y_pred=y_pred)
		TN, FP, FN, TP = cf_matrix.ravel()
		precision = TP/(TP+FP)
		recall = TP/(TP+FN)
		F1 = 2*(precision*recall)/(precision+recall)
		await f1score_message("F1 score = " + str(round(F1*100, 2)) + "%")
	finally:
		pass
	await notify_message("")

	


	


logging.basicConfig()

STATE = {"pred": 0, "truth" : 0}

USERS = set()


def state_event():
    return json.dumps({"type": "state", **STATE})


def users_event():
    return json.dumps({"type": "users", "count": len(USERS)})


async def notify_state():
    if USERS:  # asyncio.wait doesn't accept an empty list
        message = state_event()
        await asyncio.wait([user.send(message) for user in USERS])


async def notify_users():
    if USERS:  # asyncio.wait doesn't accept an empty list
        message = json.dumps({"type": "users", "pred": STATE["pred"]})
        await asyncio.wait([user.send(message) for user in USERS])


async def register(websocket):
    USERS.add(websocket)
    await load_dataset()
    

async def unregister(websocket):
    USERS.remove(websocket)
    await notify_users()


async def counter(websocket, path):


    await register(websocket)
    try:
        await websocket.send(state_event())
        async for message in websocket:
            data = json.loads(message)
            if data["action"] == "predict":
                print("Do Prediction")
                await do_prediction(json.loads(data["features"]))
            elif data["action"] == "test":
                await do_test_prediction(json.loads(data["features"]))
            elif data["action"] == "exit":
                sys.exit()
                await notify_users()
            else:
                logging.error("unsupported event: {}", data)
    finally:
        await unregister(websocket)


async def wakeup():
    while True:
        await asyncio.sleep(1)

print("Starting websocket")
start_server = websockets.serve(counter, "localhost", 6789)

print("Current directory is ", os.getcwd())
print("Open file: "  + os.path.join(os.getcwd(), 'main.html'))
webbrowser.open("file://" + os.path.join(os.getcwd(), 'main.html'), new=2)


asyncio.get_event_loop().run_until_complete(start_server)

# https://stackoverflow.com/questions/27480967/why-does-the-asyncios-event-loop-suppress-the-keyboardinterrupt-on-windows
asyncio.get_event_loop().create_task(wakeup())

asyncio.get_event_loop().run_forever()

