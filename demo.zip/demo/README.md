

README.md

1. Install

Make sure you install websockets
	pip3 install websockets

Make sure you have specific sklearn version 0.22.2:
  	pip3 install scikit-learn==0.22.2.post1


2. To Run:

Mac:

	python3 demo.py


Windows:

	python demo.py